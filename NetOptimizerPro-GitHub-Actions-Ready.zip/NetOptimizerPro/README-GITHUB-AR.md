# بناء APK من الهاتف باستخدام GitHub Actions

1. أنشئ مستودعًا جديدًا على GitHub باسم `NetOptimizerPro`.
2. ارفع **محتويات هذا المجلد** إلى جذر المستودع (بحيث يظهر `app/` و`build.gradle.kts` و`.github/` في الجذر).
3. افتح تبويب **Actions** في المستودع وفعّل GitHub Actions إذا طُلب ذلك.
4. اختر **Build Net Optimizer Pro APK** ثم **Run workflow**.
5. بعد انتهاء المهمة بنجاح، افتح تشغيل الـ workflow وانزل إلى **Artifacts**.
6. نزّل `NetOptimizerPro-debug-apk.zip`، فك ضغطه، ثم ثبّت APK على هاتفك.

ملاحظات:
- البناء يتم على خوادم GitHub، وليس على الهاتف.
- هذا ينتج APK تجريبيًا Debug، وليس إصدار متجر موقّعًا بمفتاح إصدار خاص.
- لا ترفع كلمات مرور أو مفاتيح توقيع إلى المستودع.
