# Net Optimizer Pro (Android)

An Android Studio Kotlin + Jetpack Compose starter app with real DNS-over-TLS benchmarking.

## Features
- Live Android network transport status (Wi-Fi/mobile/ethernet/offline)
- DNS-over-TLS tests against Cloudflare, Google Public DNS, and Quad9 on TCP port 853
- TLS certificate hostname verification
- Sorts providers by successful measured lookup time
- Persists the best tested hostname and recent test history
- Opens Android Private DNS settings so the user can apply the selected provider with system consent

## Build
1. Install Android Studio Ladybug or newer and Android SDK 35.
2. Open this folder in Android Studio.
3. Allow Gradle sync.
4. Build > Build Bundle(s) / APK(s) > Build APK(s).

JDK 17 is required. The project intentionally does not include a Gradle wrapper binary; Android Studio can generate/use the installed Gradle distribution.

## Important technical limits
- DNS test time is a DNS-over-TLS connection + query measurement, not ICMP ping and not game-server latency.
- Android does not let an ordinary app silently replace system-wide Private DNS. The user must apply the recommended hostname in Android Settings.
- This build does not claim to route all device traffic through a VPN or alter carrier routing/QoS.
- DNS results vary by network, carrier, region, and time. Run multiple tests for more stable comparisons.

## Suggested next production steps
- Add repeat sampling (3–5 runs per provider) and median/percentile display.
- Add an optional foreground monitoring service with a persistent notification.
- Add instrumented tests on physical devices and verify OEM-specific Private DNS settings intents.
