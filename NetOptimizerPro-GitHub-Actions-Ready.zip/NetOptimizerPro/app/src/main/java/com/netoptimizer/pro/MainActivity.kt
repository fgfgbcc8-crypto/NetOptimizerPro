package com.netoptimizer.pro

import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    private var networkLabel by mutableStateOf("Checking connection…")
    private lateinit var connectivity: ConnectivityManager
    private val callback = object : ConnectivityManager.NetworkCallback() {
        override fun onAvailable(network: Network) { runOnUiThread { networkLabel = currentNetworkLabel() } }
        override fun onLost(network: Network) { runOnUiThread { networkLabel = currentNetworkLabel() } }
        override fun onCapabilitiesChanged(network: Network, caps: NetworkCapabilities) { runOnUiThread { networkLabel = currentNetworkLabel() } }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        connectivity = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        networkLabel = currentNetworkLabel()
        try { connectivity.registerNetworkCallback(NetworkRequest.Builder().build(), callback) } catch (_: Exception) {}
        setContent { NetOptimizerApp(networkLabel) { openPrivateDnsSettings() } }
    }

    private fun currentNetworkLabel(): String {
        val caps = connectivity.getNetworkCapabilities(connectivity.activeNetwork) ?: return "Offline"
        return when {
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Connected • Wi-Fi"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "Connected • Mobile data"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "Connected • Ethernet"
            else -> "Connected • Other network"
        }
    }

    private fun openPrivateDnsSettings() {
        val intent = Intent("android.settings.PRIVATE_DNS_SETTINGS")
        try { startActivity(intent) } catch (_: Exception) { startActivity(Intent(Settings.ACTION_WIRELESS_SETTINGS)) }
    }

    override fun onDestroy() {
        try { connectivity.unregisterNetworkCallback(callback) } catch (_: Exception) {}
        super.onDestroy()
    }
}

private val Navy = Color(0xFF081426)
private val Panel = Color(0xFF12233B)
private val Cyan = Color(0xFF36D6E7)
private val Muted = Color(0xFF9FB2C9)

@Composable
fun NetOptimizerApp(network: String, openSettings: () -> Unit) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val prefs = remember { context.getSharedPreferences("net_optimizer", Context.MODE_PRIVATE) }
    var results by remember { mutableStateOf<List<DnsTester.Result>>(emptyList()) }
    var running by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("Run a DNS test to compare providers") }
    var selectedHost by remember { mutableStateOf(prefs.getString("best_host", "") ?: "") }
    var history by remember { mutableStateOf(prefs.getString("history", "") ?: "") }
    val scope = rememberCoroutineScope()
    val best = results.filter { it.success }.minByOrNull { it.latencyMs ?: Long.MAX_VALUE }

    MaterialTheme(colorScheme = darkColorScheme(primary = Cyan, background = Navy, surface = Panel)) {
        Surface(modifier = Modifier.fillMaxSize(), color = Navy) {
            LazyColumn(modifier = Modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                item {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Speed, contentDescription = null, tint = Cyan, modifier = Modifier.size(32.dp))
                        Spacer(Modifier.width(10.dp))
                        Column {
                            Text("NET OPTIMIZER", color = Color.White, fontWeight = FontWeight.Black, fontSize = 21.sp)
                            Text("PRO  •  DNS PERFORMANCE", color = Muted, fontSize = 11.sp, letterSpacing = 1.5.sp)
                        }
                    }
                }
                item {
                    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(22.dp)) {
                        Column(Modifier.fillMaxWidth().padding(18.dp)) {
                            Text("CONNECTION STATUS", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(8.dp))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Wifi, null, tint = Cyan, modifier = Modifier.size(26.dp))
                                Spacer(Modifier.width(10.dp))
                                Text(network, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                            }
                            Spacer(Modifier.height(6.dp))
                            Text("Network status is provided by Android", color = Muted, fontSize = 12.sp)
                        }
                    }
                }
                item {
                    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(22.dp)) {
                        Column(Modifier.fillMaxWidth().padding(18.dp)) {
                            Text("FASTEST TESTED DNS", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(8.dp))
                            if (best != null) {
                                Text("${best.latencyMs} ms", color = Cyan, fontSize = 38.sp, fontWeight = FontWeight.Black)
                                Text(best.server.name + " • " + best.server.host, color = Color.White)
                            } else {
                                Text("— ms", color = Color.White, fontSize = 38.sp, fontWeight = FontWeight.Black)
                                Text("No test result yet", color = Muted)
                            }
                            Spacer(Modifier.height(14.dp))
                            Button(onClick = {
                                if (!running) scope.launch {
                                    running = true; message = "Testing DNS-over-TLS providers…"
                                    val tested = withContext(Dispatchers.IO) { DnsTester.servers.map { DnsTester.test(it) } }
                                    results = tested.sortedWith(compareBy<DnsTester.Result> { !it.success }.thenBy { it.latencyMs ?: Long.MAX_VALUE })
                                    val winner = tested.filter { it.success }.minByOrNull { it.latencyMs ?: Long.MAX_VALUE }
                                    if (winner != null) {
                                        selectedHost = winner.server.host
                                        prefs.edit().putString("best_host", selectedHost).apply()
                                        val line = "${winner.server.name}: ${winner.latencyMs} ms"
                                        history = (line + "\n" + history).lines().take(10).joinToString("\n")
                                        prefs.edit().putString("history", history).apply()
                                        message = "Test complete. Best measured DNS: ${winner.server.name}."
                                    } else message = "No DNS provider responded. Check your connection or firewall."
                                    running = false
                                }
                            }, enabled = !running, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Cyan, contentColor = Navy)) {
                                if (running) { CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp, color = Navy); Spacer(Modifier.width(8.dp)); Text("TESTING…") }
                                else { Icon(Icons.Default.Bolt, null); Spacer(Modifier.width(8.dp)); Text("TEST DNS SERVERS") }
                            }
                            Spacer(Modifier.height(8.dp))
                            Text(message, color = Muted, fontSize = 12.sp)
                        }
                    }
                }
                item { Text("DNS PROVIDERS", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp) }
                items(if (results.isEmpty()) DnsTester.servers.map { DnsTester.Result(it, null, false, "Not tested yet") } else results) { result ->
                    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp)) {
                        Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(result.server.name, color = Color.White, fontWeight = FontWeight.Bold)
                                Text(result.server.description, color = Muted, fontSize = 11.sp)
                                Text(result.server.host, color = Muted, fontSize = 11.sp)
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text(if (result.success) "${result.latencyMs} ms" else if (results.isEmpty()) "—" else "Failed", color = if (result.success) Cyan else Color(0xFFFF8A80), fontWeight = FontWeight.Bold)
                                if (result.success && result.server.host == selectedHost) Text("SAVED", color = Cyan, fontSize = 10.sp)
                            }
                        }
                    }
                }
                item {
                    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(20.dp)) {
                        Column(Modifier.fillMaxWidth().padding(16.dp)) {
                            Text("APPLY DNS", color = Color.White, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(6.dp))
                            Text(if (selectedHost.isNotBlank()) "Recommended Private DNS hostname: $selectedHost" else "Run a test to select a recommended DNS provider." , color = Muted, fontSize = 12.sp)
                            Spacer(Modifier.height(12.dp))
                            OutlinedButton(onClick = openSettings, modifier = Modifier.fillMaxWidth()) {
                                Icon(Icons.Default.Settings, null); Spacer(Modifier.width(8.dp)); Text("OPEN ANDROID PRIVATE DNS SETTINGS")
                            }
                            Text("Android requires you to confirm and enter the hostname in system settings. This app does not silently change system DNS.", color = Muted, fontSize = 11.sp)
                        }
                    }
                }
                item {
                    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(20.dp)) {
                        Column(Modifier.fillMaxWidth().padding(16.dp)) {
                            Text("RECENT TEST", color = Color.White, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(8.dp))
                            Text(if (history.isBlank()) "No saved tests yet" else history, color = Muted, fontSize = 12.sp, lineHeight = 19.sp)
                        }
                    }
                }
                item {
                    Text("Note: DNS benchmark latency measures a DNS-over-TLS lookup to the provider. It is not your game-server ping and does not guarantee lower gaming latency.", color = Muted, fontSize = 11.sp)
                    Spacer(Modifier.height(10.dp))
                }
            }
        }
    }
}
