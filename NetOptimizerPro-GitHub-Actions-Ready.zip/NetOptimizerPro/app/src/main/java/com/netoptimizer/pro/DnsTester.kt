package com.netoptimizer.pro

import java.io.DataInputStream
import java.io.DataOutputStream
import java.net.InetSocketAddress
import javax.net.ssl.SSLSocket
import javax.net.ssl.SSLSocketFactory
import javax.net.ssl.SSLParameters
import kotlin.random.Random

/** DNS-over-TLS benchmark. Measures a real TLS DNS query, not game-server ping. */
object DnsTester {
    data class Server(val name: String, val host: String, val description: String)
    data class Result(val server: Server, val latencyMs: Long?, val success: Boolean, val detail: String)

    val servers = listOf(
        Server("Cloudflare", "one.one.one.one", "1.1.1.1 / DNS over TLS"),
        Server("Google", "dns.google", "Google Public DNS"),
        Server("Quad9", "dns.quad9.net", "Security-focused DNS")
    )

    fun test(server: Server): Result {
        val start = System.nanoTime()
        return try {
            val socket = SSLSocketFactory.getDefault().createSocket() as SSLSocket
            socket.soTimeout = 4500
            socket.connect(InetSocketAddress(server.host, 853), 4500)
            val params: SSLParameters = socket.sslParameters
            params.endpointIdentificationAlgorithm = "HTTPS"
            socket.sslParameters = params
            socket.startHandshake()

            val query = buildQuery("example.com")
            val output = DataOutputStream(socket.outputStream)
            output.writeShort(query.size)
            output.write(query)
            output.flush()

            val input = DataInputStream(socket.inputStream)
            val size = input.readUnsignedShort()
            if (size < 12 || size > 4096) throw IllegalStateException("Invalid DNS response")
            val response = ByteArray(size)
            input.readFully(response)
            socket.close()
            val rcode = response[3].toInt() and 0x0F
            if (rcode != 0) throw IllegalStateException("DNS response code: $rcode")
            val elapsed = (System.nanoTime() - start) / 1_000_000
            Result(server, elapsed, true, "DNS-over-TLS query succeeded")
        } catch (e: Exception) {
            Result(server, null, false, e.localizedMessage ?: "Connection failed")
        }
    }

    private fun buildQuery(domain: String): ByteArray {
        val id = Random.nextInt(0, 65536)
        val out = java.io.ByteArrayOutputStream()
        fun u16(v: Int) { out.write((v shr 8) and 0xff); out.write(v and 0xff) }
        u16(id); u16(0x0100); u16(1); u16(0); u16(0); u16(0)
        domain.split('.').forEach { label ->
            val bytes = label.toByteArray(Charsets.US_ASCII)
            out.write(bytes.size); out.write(bytes)
        }
        out.write(0); u16(1); u16(1)
        return out.toByteArray()
    }
}
